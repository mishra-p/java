connect 'jdbc:derby://localhost:1527/C:/hsbc_training_workspace/DB/fms;create=true';
create table user_ratings(userid int primary key generated always as identity(start with 1, increment by 1), name varchar(20) not null, rating decimal(1,0) not null, comment varchar(100) not null, rating_date DATE default current_date);
