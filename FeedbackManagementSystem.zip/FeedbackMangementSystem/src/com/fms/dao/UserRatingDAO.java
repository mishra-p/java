package com.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.fms.exception.DBException;
import com.fms.exception.DataAccessException;
import com.fms.exception.InsertFailedException;
import com.fms.model.UserRating;

@Repository
public class UserRatingDAO {
	
	Connection connection=null;
	@Value("${jdbc.driver}")
	String driver;
	@Value("${jdbc.url}")
	String url;
	@Value("${jdbc.user}")
	String user;
	@Value("${jdbc.password}")
	String password;
	
	//Better would have been to create a util class for handling connection????SIR???
	//Is it good to create connection in init() and close in destroy???SIR???
	//Should openConnection and close connection be in ApplicationConfiguration as bean for init and destroy????
	public void openConnection() throws DBException {
		try {
			Class.forName(driver);
			this.connection=DriverManager.getConnection(url);
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
			throw new DBException("Driver not found");
		}catch(SQLException e) {
			e.printStackTrace();
			throw new DBException("Url is not correct");
		}
	}
	
	//if user Exists do not put
	public void saveUserRating(String username,int rating,String comment) throws DBException,InsertFailedException, DataAccessException {
		PreparedStatement preparedStatement=null;
		try {
			if(this.userExists(username)){
				connection.setAutoCommit(false);
				preparedStatement=connection.prepareStatement("insert into user_ratings (name,rating,comment) values(?,?,?)");
				preparedStatement.setString(1,username);
				preparedStatement.setInt(2, rating);
				preparedStatement.setString(3, comment);
				preparedStatement.executeUpdate();
				connection.commit();
			}
			else{
				System.out.println("User has already given ratings!!!");
			}
	}catch(SQLException e) {
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				throw new DBException("Failed to rollback transcation on DB connection");
			}
			throw new InsertFailedException("Failed to save the new ratings into the Database");
		}finally {
			try {
				if(preparedStatement!=null) {
					preparedStatement.close();
				}
				if(connection!=null) {
					connection.close();
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//if user Exists do not put
		public void saveUserRating(UserRating userRating) throws DataAccessException,DBException,InsertFailedException {
			PreparedStatement preparedStatement=null;
			try {
					if(this.userExists(userRating.getName())){
						connection.setAutoCommit(false);
						preparedStatement=connection.prepareStatement("insert into user_ratings (name,rating,comment) values(?,?,?)");
						preparedStatement.setString(1,userRating.getName());
						preparedStatement.setInt(2, userRating.getRating());
						preparedStatement.setString(3, userRating.getComment());
						preparedStatement.executeUpdate();
						connection.commit();
					}
					else{
						System.out.println("User has already given ratings!!!");
					}
			}catch(SQLException e) {
				e.printStackTrace();
				try {
					connection.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					throw new DBException("Failed to rollback transcation on DB connection");
				}
				throw new InsertFailedException("Failed to save the new ratings into the Database");
			}finally {
				try {
					if(preparedStatement!=null) {
						preparedStatement.close();
					}
					if(connection!=null) {
						connection.close();
					}
				}catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		public List<UserRating> selectAll() throws DataAccessException{
			List<UserRating> userRatingsList=new ArrayList<UserRating>();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet=null;
			try {
				preparedStatement=this.connection.prepareStatement("select * from user_ratings");
				resultSet=preparedStatement.executeQuery();
				while(resultSet.next()) {
					UserRating userRating=new UserRating();
					userRating.setUserID(resultSet.getInt(1));
					userRating.setName(resultSet.getString(2));
					userRating.setRating(resultSet.getInt(3));
					userRating.setComment(resultSet.getString(4));
					userRating.setDate(resultSet.getString(5));
					userRatingsList.add(userRating);
				}
				return userRatingsList;
			}catch (SQLException e) {
				e.printStackTrace();
				throw new DataAccessException("Failed to access data from DB");
			}finally {
				try {
					if (resultSet!=null) {
						resultSet.close();
					}
					if(preparedStatement!=null) {
						preparedStatement.close();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		//Should average be calculated here or a list of ratings should have been sent?????
		public double average() throws DataAccessException{
			double totalRatings=0.0;
			int totalCount=0;
			PreparedStatement preparedStatement=null;
			ResultSet resultSet=null;
			try {
				preparedStatement=this.connection.prepareStatement("select rating from user_ratings");
				resultSet=preparedStatement.executeQuery();
				while(resultSet.next()) {
					totalRatings=totalRatings+resultSet.getInt(1);
					totalCount++;
				}
				return (totalCount>0?totalRatings/totalCount:0);
			}catch (SQLException e) {
				e.printStackTrace();
				throw new DataAccessException("Failed to access data from DB");
			}finally {
				try {
					if (resultSet!=null) {
						resultSet.close();
					}
					if(preparedStatement!=null) {
						preparedStatement.close();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		public int getTotalUsers() throws DataAccessException{
			int userCount=0;
			PreparedStatement preparedStatement=null;
			ResultSet resultSet=null;
			try {
				preparedStatement=this.connection.prepareStatement("select name from user_ratings");
				resultSet=preparedStatement.executeQuery();
				while(resultSet.next()) {
					userCount++;
				}
				return userCount;
			}catch (SQLException e) {
				e.printStackTrace();
				throw new DataAccessException("Failed to access data from DB");
			}finally {
				try {
					if (resultSet!=null) {
						resultSet.close();
					}
					if(preparedStatement!=null) {
						preparedStatement.close();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
	public boolean userExists(String username) throws DataAccessException {
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		try {
			preparedStatement=connection.prepareStatement("Select name from user_ratings where name=?");
			preparedStatement.setString(1, username);
			resultSet =preparedStatement.executeQuery();
			if(resultSet.next()) {
				return false;
			}
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DataAccessException("Failed to fetch the data from the DB");
		}finally {
			try {
				if (resultSet!=null) {
					resultSet.close();
				}
				if(preparedStatement!=null) {
					preparedStatement.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
}
