package com.fms.model;


//Should it be made component ????SIR??? because each time it is initialized so shouldn't be

public class UserRating {
	int userID;
	String name;
	int rating;
	String comment;
	String date;
	
	public UserRating() {
	}

	public UserRating(int userID, String name, int rating, String comment) {
		this.userID = userID;
		this.name = name;
		this.rating = rating;
		this.comment = comment;
	}

	public UserRating(String name, int rating, String comment) {
		this.name = name;
		this.rating = rating;
		this.comment = comment;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "UserRating [userID=" + userID + ", name=" + name + ", rating=" + rating + ", comment=" + comment
				+ ", date=" + date + "]";
	}
	
	
}
