package com.fms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fms.dao.UserRatingDAO;
import com.fms.exception.DBException;
import com.fms.exception.DataAccessException;
import com.fms.exception.InsertFailedException;
import com.fms.model.UserRating;

@Service
public class UserRatingService {
	
		@Autowired
		UserRatingDAO userRatingDAO;
		
		//Should it be autowired and how to initialize through constructor
		//@Autowired
		//UserRating userRating;
		
	
		public void addUserRating(String username,int rating,String comment) throws DataAccessException,DBException,InsertFailedException {
			userRatingDAO.openConnection();
			//userRatingDAO.saveUserRating(username,rating,comment);
			UserRating userRating=new UserRating(username, rating, comment);
			userRatingDAO.saveUserRating(userRating);
		}
		
		public List<UserRating> listAll() throws DBException,DataAccessException{
			List<UserRating> userRatingList=new ArrayList<>();
			userRatingDAO.openConnection();
			userRatingList=userRatingDAO.selectAll();
			return userRatingList;
		}
		
		public double averageRating() throws DataAccessException {
			return userRatingDAO.average();
		}
		
		public int userCount() throws DataAccessException {
			return userRatingDAO.getTotalUsers();
		}
		
}
