package com.fms.exception;

public class InsertFailedException extends Exception {
	public InsertFailedException() {
	}
	public InsertFailedException(String message) {
		super(message);
	}
}
