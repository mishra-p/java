import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.fms.dao.UserRatingDAO;
import com.fms.exception.DBException;
import com.fms.exception.DataAccessException;
import com.fms.exception.InsertFailedException;
import com.fms.model.UserRating;
import com.fms.service.UserRatingService;

public class Main {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext applicationContext=new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
		System.out.println("IOC Container Started");
		
		//Is it required??
		//UserRatingDAO userRatingDAO=applicationContext.getBean("userRatingDAO",UserRatingDAO.class);
		UserRatingService userRatingService=applicationContext.getBean("userRatingService",UserRatingService.class);
		
		try {
			userRatingService.addUserRating("Raju",2,"Bakwass!!");
			userRatingService.addUserRating("Kaju",3,"Bakwass!!");
			userRatingService.addUserRating("Baju",4,"Bakwass!!");
		} catch (DBException e) {
			e.printStackTrace();
		} catch (InsertFailedException e) {
			e.printStackTrace();
		}catch (DataAccessException e) {
			e.printStackTrace();
		}
		
		try{
			List<UserRating> userRatingsList=new ArrayList<UserRating>();
			userRatingsList=userRatingService.listAll();
			if(userRatingsList.size()>0) {
				for(UserRating userRating:userRatingsList) {
					System.out.println(userRating.toString());
				}
			}else {
				System.out.println("No Ratings given yet!!!");
			}
		}catch (DBException e) {
			e.printStackTrace();
		}catch(DataAccessException e) {
			e.printStackTrace();
		}
		
		try {
			System.out.printf("The average user ratings is %s\n",userRatingService.averageRating());
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		
		try {
			System.out.printf("The total users are %s\n",userRatingService.userCount());
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		applicationContext.close();
		System.out.println("IOC Container Stopped!!");
		
	}
}
